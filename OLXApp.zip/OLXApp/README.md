Development of clone OLX using Java Android
